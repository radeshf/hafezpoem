### Hafez Poem

##Give you random poem of hafez

You can use this for factor of restaurants and other stuff

USAGE:
```python
from hafezpoem import get_random_fal
fal = get_random_fal()
print(fal)
```

RESULT:
```python
"""مطرب عشق عجب ساز و نوايي دارد\nنقش هر نغمه که زد راه به جايي دارد"""
```

## License
hafezpoem is published under the [MIT license](https://en.wikipedia.org/wiki/MIT_License).  